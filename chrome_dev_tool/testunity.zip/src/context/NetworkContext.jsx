import React, { createContext, useState } from 'react';

export const NetworkContext = createContext();

export const NetworkProvider = ({ children }) => {
  const [requests, setRequests] = useState([]);
  const [filter, setFilter] = useState('all');
  
  return (
    <NetworkContext.Provider value={{ requests, setRequests, filter, setFilter }}>
      {children}
    </NetworkContext.Provider>
  );
};
