
export function FetchData(){
   async function getData(){
        try {
            let resp=await fetch("https://reqres.in/api/users?page=2")
            let ans=await resp.json()  
            console.log(ans)         
        } catch (error) {
            console.log(error);
        }
    }
    return <>
      <button onClick={getData}>Fetch Data</button>
    </>
}