import React, { useState } from 'react';

const RequestDetail = () => {
  const [selectedRequest, setSelectedRequest] = useState(null);

  return (
    <div>
      <h2>Request Details</h2>
      {selectedRequest ? (
        <div>
          <p><strong>URL:</strong> {selectedRequest.url}</p>
          <p><strong>Method:</strong> {selectedRequest.method}</p>
          <p><strong>Status:</strong> {selectedRequest.status}</p>
          <p><strong>Headers:</strong> {selectedRequest.headers}</p>
          <p><strong>Time:</strong> {selectedRequest.time.toString()}</p>
        </div>
      ) : (
        <p>Select a request to see details</p>
      )}
    </div>
  );
};

export default RequestDetail;
